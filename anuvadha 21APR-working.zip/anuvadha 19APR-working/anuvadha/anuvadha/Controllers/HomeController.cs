﻿using anuvadha.Models;
using Google.Cloud.Translation.V2;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Google.Cloud.TextToSpeech.V1;
using System;
using System.IO;
using System.Net.Http.Headers;
using static System.Net.Mime.MediaTypeNames;
using System.Runtime.InteropServices;
using NAudio.Wave;
using Whisper.net.Ggml;
using Whisper.net;
using System.Text.Json;
using System.Security.Cryptography.X509Certificates;

namespace anuvadha.Controllers
{
    //[CustomExceptionFilter]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;


        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;

        }

        private readonly string GOOGLE_TRANSLATION_API_KEY = "AIzaSyBh7oFZYJbqLw47GdiGUCK_miV-18DvfCI";
        private static string S2T_API_URL = "http://127.0.0.1:3000/upload";
        private static string CLONING_API_URL = "http://127.0.0.1:5000/upload";


        public async Task<byte[]> tToS(string text, string languageCode)
        {
            var client = new HttpClient();
            SpeechToTextRequestModel reqContent = new SpeechToTextRequestModel()
            {
                input = new()
                {
                    new ReqInput() { source = text }
                },
                config = new()
                {
                    gender = "male", //female
                    language = new()
                    {
                        sourceLanguage = languageCode
                    }
                }

            };
            string stringCOntent = JsonSerializer.Serialize(reqContent);
            var request = new HttpRequestMessage()
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri("https://tts-api.ai4bharat.org/"),
                Content = new StringContent(stringCOntent)
                {
                    Headers = {
                        ContentType = new MediaTypeHeaderValue("application/json")
                    }
                }
            };

            using (var response = await client.SendAsync(request))
            {

                response.EnsureSuccessStatusCode();
                var resString = await response.Content.ReadAsStringAsync();

                SpeechToTextResponceModel responceModel = Newtonsoft.Json.JsonConvert.
                    DeserializeObject<SpeechToTextResponceModel>(resString);

                var base64String = responceModel.audio[0].audioContent;
                byte[] binaryData = Convert.FromBase64String(base64String);

                //string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\uploads");
                //if (!Directory.Exists(path))
                //{
                //    Directory.CreateDirectory(path);
                //}

                //string filename = path + "robotic_translated_voice.wav";
                //System.IO.File.WriteAllBytes(filename, binaryData);

                return binaryData;

            }



        }

        public async Task<IActionResult> IndexAsync()
        {
            return View();
        }

        

        private async Task<string> TransScript(string fileName, string AudioPath)
        {
            using (HttpClient client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(new HttpMethod("POST"), S2T_API_URL))
                {
                    var fileContent = new ByteArrayContent(System.IO.File.ReadAllBytes(AudioPath));
                    fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("audio/wav");
                    var formData = new MultipartFormDataContent();

                    formData.Add(fileContent, "audio", "" + fileName);
                    request.Content = formData;

                    using (var response = await client.SendAsync(request))
                    {
                        response.EnsureSuccessStatusCode();

                        var responseContent = await response.Content.ReadAsStringAsync();
                        var TranscriptedText = JsonSerializer.Deserialize<InputText>(responseContent);
                        string transcript = TranscriptedText.message;

                        return transcript;
                    };

                };
            };
        }

        private string[] TranslateText(string text, string targetLanguage)
        {
            string[] result = new string[2];
            using (var client = TranslationClient.CreateFromApiKey(GOOGLE_TRANSLATION_API_KEY))
            {
                var response = client.TranslateText(text, targetLanguage);
                result[0] = response.TranslatedText;
                result[1] = response.OriginalText;
                return result;
            };


        }


        [HttpPost]
        public async Task<IActionResult> PlayerAsync(IFormFile PostedAudioFile,string languages)
        {


            string filenamePrefix = PostedAudioFile.FileName.Replace(".wav", "");

            string RootDirectory = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot\\AudioFiles\\{filenamePrefix}\\");
            if (!Directory.Exists(RootDirectory))
            {
                Directory.CreateDirectory(RootDirectory);
            }


            string OriginalfileName = filenamePrefix + "_Original.wav";


            //saving original
            string OriginalAudioFilePath = Path.Combine(RootDirectory, OriginalfileName);
            using (FileStream stream = new FileStream(OriginalAudioFilePath, FileMode.Create))
            {
                PostedAudioFile.CopyTo(stream);
            }
            _logger.LogInformation("FileUploaded : " + OriginalAudioFilePath);

            _logger.LogInformation(">>>>>Transcripting");
            //>>>transcript
            string transcript = await TransScript(OriginalfileName, OriginalAudioFilePath);
            _logger.LogInformation("TransScription : " + transcript);

            _logger.LogInformation(">>>>>Translating to !"+languages);
            //>>>Translate
            //translations[0] -->translatied text
            //translations[1] -->Original Text
            string TargetLanguage = languages;
            var translations = TranslateText(transcript, TargetLanguage);
            string TranslatedText = translations[0];
            _logger.LogInformation("Translation done !");

            _logger.LogInformation(">>>>>Generating speech from transcript!");
            //>>>textToSpeech --robotic
            var RoboticAudioFileBytes = await tToS(TranslatedText, languages);
            string RoboticFileName = filenamePrefix + "_Translated_robotic.wav";
            string RoboticFilePath = Path.Combine(RootDirectory, RoboticFileName);
            System.IO.File.WriteAllBytes(RoboticFilePath, RoboticAudioFileBytes);
            _logger.LogInformation("Robotic Voice generated at " + RoboticFilePath);

            _logger.LogInformation(">>>>>Cloning voice!");
            //>>>CloneVoice
            Stream clonedAudioStream = await clone(RoboticFilePath, OriginalAudioFilePath);
            string clonedFileName = filenamePrefix + "_Translated_cloned.wav";
            string clonedAudioFilePath = Path.Combine(RootDirectory, clonedFileName);

            WaveFileReader waveFileReader = new WaveFileReader(clonedAudioStream);
            WaveFileWriter.CreateWaveFile(clonedAudioFilePath, waveFileReader);
            _logger.LogInformation("cloned voice audio file saved at " + clonedAudioFilePath);



            ViewBag.RoboticTranslated = "data:audio/wav;base64," +
                Convert.ToBase64String(
                    System.IO.File.ReadAllBytes(RoboticFilePath));

            ViewBag.OriginalFile = "data:audio/wav;base64," +
                Convert.ToBase64String(System.IO.File.ReadAllBytes(OriginalAudioFilePath));

            ViewBag.ClonedAudio = "data:audio/wav;base64," +
                Convert.ToBase64String(System.IO.File.ReadAllBytes(clonedAudioFilePath));

            ViewBag.TranslatedText = TranslatedText;
            ViewBag.Transcript = transcript;

            return View("temp");

        }


       

        static async Task<Stream> clone(string robotic, string original)
        {

            //cloning
            var client = new HttpClient();
            using (var request = new HttpRequestMessage(new HttpMethod("POST"),
                "http://127.0.0.1:5000/upload"))
            {
                var RoboticFileContent = new ByteArrayContent(System.IO.File.ReadAllBytes(robotic));
                var OriginaltFileContent = new ByteArrayContent(System.IO.File.ReadAllBytes(original));

                RoboticFileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("audio/wav");
                OriginaltFileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("audio/wav");

                var formData = new MultipartFormDataContent();
                formData.Add(RoboticFileContent, "audio", "robotic.wav");
                formData.Add(OriginaltFileContent, "audio", "original.wav");

                request.Content = formData;
                var response = await client.SendAsync(request);

                var responseContent = await response.Content.ReadAsStreamAsync();
                return responseContent; ;
              

            }
        }

        public IActionResult Dummy()
        {
            return View();
        }

        public IActionResult Dummy2()
        {
            return View();
        }


    }
}