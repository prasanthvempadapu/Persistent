﻿namespace anuvadha.Models
{
    public class InputText
    {
        public string message { get; set; }
    }
}
